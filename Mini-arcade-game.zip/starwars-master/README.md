# starwars shooting game
Use mouse to move and arrow up to shoot. 
Shoot coins to gain score!
:)
